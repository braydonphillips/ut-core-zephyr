#ifndef CORE_CONTROLLERBDOT_HPP
#define CORE_CONTROLLERBDOT_HPP

#include "core_Parameters.hpp"
#include "core_Saturate.hpp"

class ControllerBDot {
public: 

    // Type Aliases for readability
    using StateVector = Param::Vector7;
    using Vector3 = Param::Vector3;
    using Measurements = Param::Vector13;
    using Scalar = Param::Real;

    // Constructor
    ControllerBDot();

    // Update method - takes measurements and current estimated states
    Vector3 update(const Measurements& measurements, const Param::Vector11& states_hat, Scalar dt);
    
private:
    Scalar m_min, m_max;
    Scalar K_Bdot;
    Vector3 B_prev;
    Vector3 B_dot;
    Scalar alpha_Bdot;
    Vector3 Bdot_num_filt;
    Scalar beta_fuse;
};
#endif // CORE_CONTROLLERBDOT_HPP